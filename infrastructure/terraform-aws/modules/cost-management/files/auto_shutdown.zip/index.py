import boto3
import os

def handler(event, context):
    """Stop non-essential dev/staging resources outside business hours."""

    environment = os.environ.get('ENVIRONMENT', 'dev')
    action = event.get('action', 'stop')

    ec2 = boto3.client('ec2')
    rds = boto3.client('rds')

    # Stop/Start EC2 instances with AutoShutdown=true
    instances = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:AutoShutdown', 'Values': ['true']},
            {'Name': 'tag:Environment', 'Values': [environment]},
            {'Name': 'instance-state-name', 'Values': ['running' if action == 'stop' else 'stopped']}
        ]
    )

    instance_ids = [
        i['InstanceId']
        for r in instances['Reservations']
        for i in r['Instances']
    ]

    if instance_ids:
        if action == 'stop':
            ec2.stop_instances(InstanceIds=instance_ids)
            print(f"Stopped {len(instance_ids)} EC2 instances")
        else:
            ec2.start_instances(InstanceIds=instance_ids)
            print(f"Started {len(instance_ids)} EC2 instances")

    # Stop/Start RDS instances
    dbs = rds.describe_db_instances()
    for db in dbs['DBInstances']:
        try:
            tags = {t['Key']: t['Value'] for t in rds.list_tags_for_resource(
                ResourceName=db['DBInstanceArn'])['TagList']}

            if tags.get('AutoShutdown') == 'true' and tags.get('Environment') == environment:
                if action == 'stop' and db['DBInstanceStatus'] == 'available':
                    rds.stop_db_instance(DBInstanceIdentifier=db['DBInstanceIdentifier'])
                    print(f"Stopped RDS: {db['DBInstanceIdentifier']}")
                elif action == 'start' and db['DBInstanceStatus'] == 'stopped':
                    rds.start_db_instance(DBInstanceIdentifier=db['DBInstanceIdentifier'])
                    print(f"Started RDS: {db['DBInstanceIdentifier']}")
        except Exception as e:
            print(f"Error processing RDS {db['DBInstanceIdentifier']}: {e}")

    return {
        'statusCode': 200,
        'body': f"Completed {action} action for {environment}"
    }
